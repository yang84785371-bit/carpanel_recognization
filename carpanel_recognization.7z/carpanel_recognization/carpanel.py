import cv2, numpy as np, pytesseract, re

import os, shutil

from PIL import Image, ImageDraw, ImageFont

from math import acos, pi

TESS_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
if os.path.exists(TESS_PATH):
    pytesseract.pytesseract.tesseract_cmd = TESS_PATH
else:
    found = shutil.which("tesseract")
    if found:
        pytesseract.pytesseract.tesseract_cmd = found
    else:
        raise RuntimeError("未找到 tesseract，请先安装或把安装目录加入系统 PATH。")

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
print("tesseract:", pytesseract.get_tesseract_version())


PROVINCES = "京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领"
PLATE_RE = re.compile(rf"[{PROVINCES}][A-Z][A-Z0-9]{5,6}")
FIRST_ALPHA_MAP = str.maketrans({"0":"Q","1":"I","2":"Z","5":"S","8":"B"})  # 数字→字母（第1位纠错）
REST_NUM_MAP    = str.maketrans({"O":"0","Q":"0","I":"1","L":"1","Z":"2","S":"5","B":"8"})  # 其余位字母→数字（可选）

def cv_show(name ,img):
	cv2.imshow(name, img)
	cv2.waitKey(0)
	cv2.destroyAllWindows()

def _pad_white(img, pad=12):
    return cv2.copyMakeBorder(img, pad,pad,pad,pad, cv2.BORDER_CONSTANT, value=255)

def _char_ocr(bin_char, whitelist, psm=10, lang="eng"):
    cfg = f"--oem 3 --psm {psm} -l {lang} -c tessedit_char_whitelist={whitelist}"
    s = pytesseract.image_to_string(bin_char, config=cfg)
    return s.strip().replace(" ", "").replace("\n","")

# --- 颜色掩膜 ---
def white_mask(img):  # 低S+高V 的白/银边
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    return cv2.inRange(hsv, (0, 0, 185), (179, 70, 255))

def blue_mask(img):   # 稍严格一点的蓝
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    B,G,R = cv2.split(img)
    m_hsv  = cv2.inRange(hsv, (95,70,50), (140,255,255))
    m_dom  = (B.astype(np.int16) - np.maximum(R,G).astype(np.int16) > 15).astype(np.uint8)*255
    m_ratio= (2*B.astype(np.int16) > (R+G).astype(np.int16) + 20).astype(np.uint8)*255
    m = cv2.bitwise_and(m_hsv, cv2.bitwise_and(m_dom, m_ratio))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT,(15,5)), 2)
    m = cv2.medianBlur(m, 5)
    # 去极小连通域（格栅小蓝点）
    H,W = m.shape; th = int(0.002*H*W)
    num,lbl,stats,_ = cv2.connectedComponentsWithStats(m, 4)
    out = np.zeros_like(m)
    for i in range(1,num):
        if stats[i, cv2.CC_STAT_AREA] >= th: out[lbl==i]=255
    return out




# --- 几何/文字性 ---
def angle_score(box):
    box = np.array(cv2.convexHull(box.astype(np.float32))).reshape(-1,2)
    if len(box)!=4: return 0.0
    def cosang(a,b,c):
        v1,v2=a-b,c-b
        n1=np.linalg.norm(v1)+1e-6; n2=np.linalg.norm(v2)+1e-6
        return abs(np.clip(np.dot(v1,v2)/(n1*n2), -1, 1))  # 直角→0
    cs=[cosang(box[(i-1)%4],box[i],box[(i+1)%4]) for i in range(4)]
    return 1.0-float(np.mean(cs))

def textness(roi):
    g=cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    g=cv2.medianBlur(g,3)
    s1=cv2.threshold(g,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]
    s2=cv2.threshold(g,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
    def cc(bw):
        H,W=bw.shape
        num,_,stats,_=cv2.connectedComponentsWithStats(bw,4)
        cnt=0
        for i in range(1,num):
            x,y,w,h,a=stats[i]; ar=w/(h+1e-6)
            if 0.15*H<h<0.8*H and 0.15<ar<1.8 and 0.002*H*W<a<0.2*H*W: cnt+=1
        return min(1.0,cnt/8.0)
    return max(cc(s1),cc(s2))

# --- 关键：在“蓝连通域周围的环带”里计算白环占比 ---
def ring_ratio_around_cc(blue_cc_mask, white_mask_full):
    # 自适应环宽：按候选尺寸的 4~7%
    ys,xs = np.where(blue_cc_mask>0)
    if len(xs)==0: return 0.0
    x0,x1 = xs.min(), xs.max(); y0,y1 = ys.min(), ys.max()
    w = x1-x0+1; h = y1-y0+1; s = min(w,h)
    rin  = max(1, int(0.04*s))
    rout = max(rin+1, int(0.07*s))

    k_in  = cv2.getStructuringElement(cv2.MORPH_RECT,(rin,rin))
    k_out = cv2.getStructuringElement(cv2.MORPH_RECT,(rout,rout))
    band  = cv2.subtract(cv2.dilate(blue_cc_mask, k_out), cv2.erode(blue_cc_mask, k_in))
    inter = cv2.bitwise_and(band, white_mask_full)
    num = cv2.countNonZero(inter); den = cv2.countNonZero(band)+1e-6
    return num/den  # 0~1

def find_plate_bbox(img_bgr):
    H0,W0 = img_bgr.shape[:2]
    # 统一尺度
    target=900; scale = target/max(H0,W0) if max(H0,W0)>target else 1.0
    small=cv2.resize(img_bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    H,W=small.shape[:2]; area_img=H*W

    m_blue  = blue_mask(small)
    m_white = white_mask(small)

    #cv_show("blue",m_blue)
    #cv_show("blue",m_white)

    # 用蓝掩膜的连通域作为候选（而不是整图白圈），再在每个候选周围找白环
    num, lbl, stats, _ = cv2.connectedComponentsWithStats(m_blue, 4)

    best=None; best_score=-1.0
    for i in range(1,num):
        x,y,w,h,a = stats[i]
        frac = a/(area_img+1e-6)
        if not (0.003 <= frac <= 0.35):  # 尺寸粗筛
            continue

        cc = (lbl==i).astype(np.uint8)*255

        # 蓝芯（内缩后蓝占比，避开白边）
        xi = x+int(0.06*w); yi=y+int(0.10*h)
        xj = x+w-int(0.06*w); yj=y+h-int(0.10*h)
        xi,yi=max(0,xi),max(0,yi); xj,yj=min(W,xj),min(H,yj)
        if xj<=xi or yj<=yi: continue
        blue_core = cv2.countNonZero(m_blue[yi:yj, xi:xj])/(((xj-xi)*(yj-yi))+1e-6)

        # 白环：只在该蓝连通域“周围环带”里统计白色
        white_ring = ring_ratio_around_cc(cc, m_white)

        # 几何：minAreaRect + 直角度 + 紧致度 + 宽高比惩罚(不卡死)
        c = cv2.findContours(cc, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0][0]
        rect = cv2.minAreaRect(c); (rw,rh)=sorted(rect[1])
        if rh<8: continue
        ar = rw/(rh+1e-6)
        ar_score = np.exp(-((ar-4.0)**2)/(2*1.2*1.2))       # 0~1
        box = cv2.boxPoints(rect).astype(np.int32)
        right = angle_score(box)
        hull_area = cv2.contourArea(cv2.convexHull(c))+1e-6
        solidity  = cv2.contourArea(c)/hull_area

        # 文字性（内缩区）
        roi = small[yi:yj, xi:xj]
        txt = textness(roi)

        # 位置轻惩罚
        cx,cy = x+w/2, y+h/2
        pos_pen = 1.0 + abs(cx-W/2)/(W/2) + abs(cy-0.60*H)/H

        # 综合评分（蓝芯+白环为主，几何/文字辅助）
        score = (0.32*blue_core + 0.26*white_ring
                 + 0.22*(0.6*right + 0.4*ar_score)
                 + 0.12*solidity + 0.08*txt)
        score = score * frac / pos_pen

        if score > best_score:
            best_score, best = score, (x,y,w,h)

    if best is None:
        return None

    # 映回原图
    x,y,w,h = best
    inv = 1.0/scale
    x = int(round(x*inv)); y = int(round(y*inv))
    w = int(round(w*inv)); h = int(round(h*inv))
    x = max(0, min(W0-1, x)); y = max(0, min(H0-1, y))
    w = max(1, min(W0-x, w)); h = max(1, min(H0-y, h))
    return (x,y,w,h)



def ocr_province_char(plate_bgr):
    h, w = plate_bgr.shape[:2]
    # 1) 省份字 ROI：左侧 ~18% 宽（可调 0.16~0.22），上下留边
    pad_y = int(0.13 * h)
    x1 = int(0.15 * w)
    roi = plate_bgr[pad_y:h-pad_y, 0:x1]

    #cv_show("roi",roi)

    # 2) 预处理：灰度→放大（高度约 100）→中值去噪→黑字白底
    g = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    scale = max(2, int(100 / max(1, g.shape[0])))
    g = cv2.resize(g, None, fx=3.5, fy=scale, interpolation=cv2.INTER_LINEAR)
    g = cv2.medianBlur(g, 3)
    bin_inv = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]

    roi_shape = roi.shape
    bin_inv[-int(0.1*roi_shape[0]):,:] = 255
    bin_inv[:, :int(0.10*w)] = 255
    #cv_show("roi",bin_inv)

    # 3) 加白边，避免贴边
    bin_inv = cv2.copyMakeBorder(bin_inv, 20,20,20,20, cv2.BORDER_CONSTANT, value=255)
    #cv_show("roi",bin_inv)
    # 4) OCR（先不要白名单；psm 换 8/7 兜底）
    for psm in (8, 7):
        cfg = f"--oem 1 --psm {psm} -l chi_sim"
        raw = pytesseract.image_to_string(bin_inv, config=cfg)
        ch = raw.strip().replace(" ", "").replace("\n","") 
        for c in  ch:
            if c in PROVINCES:
                return c
    return ""

def remove_border_blobs(bin_inv):
    # bin_inv: 黑字白底 (0=黑, 255=白)
    H, W = bin_inv.shape
    fg = 255 - bin_inv                                   # 前景=白
    num, labels, stats, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)

    keep = np.zeros_like(fg)
    for i in range(1, num):                              # 0是背景
        x,y,w,h,area = stats[i]
        # 触边的组件（含上边框、与边框相连的铆钉）丢弃
        if x == 0 or y == 0 or x+w == W or y+h == H:
            continue
        keep[labels == i] = 255

    return 255 - keep

def ocr_engnum_part(plate_bgr, debug=False):
    """
    从车牌图（含省份字）里识别英数部分：
    - 先跳过左侧省份字区域；
    - 只取“蓝色内的白色”连通域作为字符候选；
    - 逐字 OCR（首位字母，其余英数），并做轻度纠错；
    - 兜底：候选太少时整行识别。
    返回：字符串（仅 A-Z/0-9，最多 6 位）
    """
    H, W = plate_bgr.shape[:2]

    # ---- 1) 跳过省份字与上下边少量留白（温和，不会切到字） ----
    x0   = int(0.15 * W)               # 省份+分隔点大致宽度
    padY = int(0.06 * H)
    roi  = plate_bgr[padY:H-padY, x0:W] if x0 < W-5 else plate_bgr
    #cv_show("roi",roi)
    Hr, Wr = roi.shape[:2]

    # ---- 2) 只取“蓝色里被包裹的白色” ----
    def _blue_mask(img):
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        B,G,R = cv2.split(img)
        m_hsv  = cv2.inRange(hsv, (95,70,50), (140,255,255))
        m_dom  = (B.astype(np.int16) - np.maximum(R,G).astype(np.int16) > 15).astype(np.uint8)*255
        m_ratio= (2*B.astype(np.int16) > (R+G).astype(np.int16) + 20).astype(np.uint8)*255
        m = cv2.bitwise_and(m_hsv, cv2.bitwise_and(m_dom, m_ratio))
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (max(7,Wr//60), max(3,Hr//120)))
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, k, 2)
        m = cv2.medianBlur(m, 5)
        return m

    def _white_mask(img):
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask_hsv  = cv2.inRange(hsv, (0,0,185), (179,70,255))
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        mask_otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
        return cv2.bitwise_and(mask_hsv, mask_otsu)

    blue = _blue_mask(roi)
    cv_show("blue",blue)
    # 轻内缩，排除白边（按尺寸自适应，不会吃到笔画）
    k_in  = cv2.getStructuringElement(cv2.MORPH_RECT, (max(3,Wr//100), max(3,Hr//100)))
    blue_core = cv2.erode(blue, k_in, 1)
    cv_show("blue_core",blue_core)
    white = _white_mask(roi)
    char_mask = cv2.bitwise_and(white, blue_core)   # 只保留蓝内部的白

    # ---- 3) 连通域 → 字符候选 ----
    num, labels, stats, centroids = cv2.connectedComponentsWithStats(char_mask, 4)
    boxes = []
    for i in range(1, num):
        x,y,w,h,a = stats[i]
        ar = w/(h+1e-6)
        if not (0.20 <= ar <= 1.30):        # 字符大多瘦高
            continue
        if not (0.40*Hr <= h <= 0.97*Hr):   # 高度覆盖
            continue
        # 圆度 + 位置排除柳钉
        comp = (labels==i).astype(np.uint8)*255
        cnts,_ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts: 
            continue
        A = cv2.contourArea(cnts[0]); P = cv2.arcLength(cnts[0], True)+1e-6
        circ = 4*np.pi*A/(P*P)              # 圆=1
        cy = y + h/2.0
        if circ > 0.70 and cy < 0.45*Hr:    # 小圆且靠上，多半是柳钉
            continue
        boxes.append((x,y,w,h))

    boxes.sort(key=lambda b:b[0])           # 左到右 = 字符顺序

    if debug:
        vis = roi.copy()
        for (x,y,w,h) in boxes:
            cv2.rectangle(vis,(x,y),(x+w,y+h),(0,255,0),2)
        cv2.imshow("engnum_mask", char_mask)
        cv2.imshow("engnum_boxes", vis)
        cv2.waitKey(0)

    # ---- 4) 候选太少 → 整行兜底 ----
    if len(boxes) < 4:
        cfg = "--oem 1 --psm 7 -l eng -c tessedit_char_whitelist=ABCDEFGHJKLMNPQRSTUVWXYZ0123456789"
        s = pytesseract.image_to_string(roi, config=cfg).upper()
        s = s.replace(" ","").replace("\n","")
        # 只保留英数，最多 6 位
        s = "".join(ch for ch in s if ch.isalnum())[:6]
        return s

    # ---- 5) 逐字 OCR（psm=10），首位字母，其余英数 + 轻纠错 ----
    FIRST_ALPHA_MAP = str.maketrans({"0":"Q","1":"I","5":"S","8":"B"})
    REST_NUM_MAP    = str.maketrans({"O":"0","I":"1","S":"5","Z":"2","B":"8"})

    def _ocr_single(img, whitelist):
        g  = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        bw = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)[1]
        bw = cv2.copyMakeBorder(bw, 20,20,20,20, cv2.BORDER_CONSTANT, value=255)
        cfg = f"--oem 1 --psm 10 -l eng -c tessedit_char_whitelist={whitelist}"
        t = pytesseract.image_to_string(bw, config=cfg).strip().upper()
        return t[:1] if t else ""

    out=[]
    for i,(x,y,w,h) in enumerate(boxes[:7]):   # 取前 6~7 个
        ch_img = roi[y:y+h, x:x+w]
        if i == 0:
            ch = _ocr_single(ch_img, "ABCDEFGHJKLMNPQRSTUVWXYZ")
            ch = ch.translate(FIRST_ALPHA_MAP) if ch else ""
        else:
            ch = _ocr_single(ch_img, "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789")
            ch = ch.translate(REST_NUM_MAP) if ch else ""
        out.append(ch if ch else "?")

    s = "".join(out)
    # 只保留英数，并截到 6 位（例如 C GT009）
    s = "".join(ch for ch in s if ch.isalnum())[:6]
    return s



def ocr_plate(plate_img):
    prov = ocr_province_char(plate_img)            # 省份位（只会是 31 选 1）
    tail = ocr_engnum_part(plate_img)              # 英数字（6 或 7 位，取你需要的长度）
    text = (prov + tail) if prov else tail

    # 正则兜底校验
    m = PLATE_RE.search(text)
    return (m.group(0) if m else text), plate_img

def put_text_cn(img_bgr, text, org, font_path=r"C:\Windows\Fonts\msyh.ttc",
                font_size=32, color=(0,255,0)):
    # OpenCV(BGR) → PIL(RGB)
    img_pil = Image.fromarray(cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    font = ImageFont.truetype(font_path, font_size)
    draw.text(org, text, font=font, fill=(color[2], color[1], color[0]))  # PIL用RGB
    # PIL(RGB) → OpenCV(BGR)
    return cv2.cvtColor(np.asarray(img_pil), cv2.COLOR_RGB2BGR)


def main(path):
    img = cv2.imread(path)
    #cv_show10("raw car panel",img)
    bbox = find_plate_bbox(img)
    if not bbox:
        print("未定位到车牌"); 
    '''
    x, y, w, h = bbox
    roi = img[y:y+h, x:x+w]                 # 注意先行(y)后列(x)
    zoom = cv2.resize(roi, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)  # 放大看
    cv2.imshow("plate_roi", zoom); cv2.waitKey(0)
    '''

    x,y,w,h = bbox
    plate = img[y:y+h, x:x+w].copy()
    cv_show("plate",plate)
    plate_text, vis = ocr_plate(plate)

    out = img.copy()
    out = cv2.rectangle(out, (x,y), (x+w,y+h), (0,255,0), 2)
    cv_show("out",out)
    out = put_text_cn(out, plate_text, (x+100, y), font_size=36, color=(0,0,255))
    cv_show("result", out)

    print("dudu")
    print("dudu")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("-i","--image", required=True)
    args = ap.parse_args()
    main(args.image)
